    <nav class="navbar navbar-expand-lg bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-primary" href="#">
                <img src="<?php echo e(asset('clients/images/logo/logo.png')); ?>" alt="Peace Logo" height="120" class="me-2">
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('home')); ?>">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('about')); ?>">About</a></li>
                    
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('support.request.index')); ?>">Support
                            Request</a></li>
                    <li class="nav-item"><a class="nav-link"
                            href="<?php echo e(route('clients.photo-gallery.photo-gallery')); ?>">Photo
                            Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('clients.video-gallery.video-gallery')); ?>">Video
                            Gallery</a></li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a></li>

                    <?php if(empty(Auth::user()->id)): ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>">Register</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                    <?php endif; ?>

                </ul>
                <a href="<?php echo e(route('donate.index')); ?>" class="btn btn-primary ms-lg-3">Donate</a>
            </div>
        </div>
    </nav>
<?php /**PATH D:\peace-int\resources\views/clients/components/navbar.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Peace International Human Rights</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo e(asset('clients/css/style.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('clients/css/style-fb-card.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('clients/css/activities.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('clients/css/problems.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('clients/css/footer.css')); ?>" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" />

    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <!-- Navbar -->
    <?php echo $__env->make('clients.components.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <!-- Footer -->
    <?php echo $__env->make('clients.components.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\peace-int\resources\views/clients/master-layout.blade.php ENDPATH**/ ?>